/****************************************************
 * MongoDB Lab Week 13
 * Jalankan di mongosh
 ****************************************************/

// 0) BUAT / RESET DATABASE
// use ecommerce_lab13;
// db.customers.drop();
// db.products.drop();
// db.orders.drop();

// 1) CUSTOMERS
const customers = [
  {
    _id: ObjectId(),
    name: "Alice Johnson",
    email: "alice@gmail.com",
    address: { city: "Jakarta", zip: "12345" },
    phones: ["081234567890", "081298765432"],
  },
  {
    _id: ObjectId(),
    name: "Bob Smith",
    email: "bob@outlook.com",
    address: { city: "Bandung", zip: "40123" },
    phones: ["082233445566"],
  },
  {
    _id: ObjectId(),
    name: "Charlie Brown",
    email: "charlie@yahoo.com",
    address: { city: "Jakarta", zip: "12560" },
    phones: ["083344556677", "083355577799"],
  },
  {
    _id: ObjectId(),
    name: "Diana Evans",
    email: "diana@gmail.com",
    address: { city: "Surabaya", zip: "60231" },
    phones: ["084455667788"],
  },
  {
    _id: ObjectId(),
    name: "Evan Thomas",
    email: "evan@company.co.id",
    address: { city: "Bandung", zip: "40211" },
    phones: ["085566778899", "085500112233", "085512341234"],
  },
  {
    _id: ObjectId(),
    name: "Farah Rahma",
    email: "farah.rahma@gmail.com",
    address: { city: "Yogyakarta", zip: "55123" },
    phones: ["086677889900"],
  },
];
db.customers.insertMany(customers);

// 2) PRODUCTS
const products = [
  {
    _id: ObjectId(),
    name: "Laptop Pro 14",
    category: "Electronics",
    price: 15000000,
    stock: 10,
    tags: ["tech", "computer", "device"],
  },
  {
    _id: ObjectId(),
    name: "Smartphone X",
    category: "Electronics",
    price: 7000000,
    stock: 20,
    tags: ["tech", "mobile"],
  },
  {
    _id: ObjectId(),
    name: "Tablet Air",
    category: "Electronics",
    price: 4500000,
    stock: 15,
    tags: ["tech", "tablet"],
  },
  {
    _id: ObjectId(),
    name: "Wireless Headset",
    category: "Electronics",
    price: 1200000,
    stock: 30,
    tags: ["audio", "device"],
  },
  {
    _id: ObjectId(),
    name: "Running Shoes",
    category: "Fashion",
    price: 900000,
    stock: 25,
    tags: ["sport", "fashion"],
  },
  {
    _id: ObjectId(),
    name: "Jacket Windbreaker",
    category: "Fashion",
    price: 650000,
    stock: 18,
    tags: ["outerwear", "fashion"],
  },
  {
    _id: ObjectId(),
    name: "Coffee Beans 1kg",
    category: "Groceries",
    price: 220000,
    stock: 40,
    tags: ["coffee", "food"],
  },
  {
    _id: ObjectId(),
    name: "Mechanical Keyboard",
    category: "Electronics",
    price: 1800000,
    stock: 12,
    tags: ["tech", "keyboard"],
  },
];
db.products.insertMany(products);

// helper maps (agar mudah refer product & customer by name)
const byProduct = Object.fromEntries(products.map((p) => [p.name, p._id]));
const byCustomer = Object.fromEntries(customers.map((c) => [c.name, c._id]));

// 3) ORDERS
//   - Variasikan status: completed / pending / cancelled
//   - Pastikan ada items dengan quantity > 2 (untuk $elemMatch)
//   - Tanggal di tahun 2024 untuk latihan agregasi per-bulan
const orders = [
  {
    _id: ObjectId(),
    customer_id: byCustomer["Alice Johnson"],
    order_date: ISODate("2024-01-15T10:20:00Z"),
    items: [
      { product_id: byProduct["Laptop Pro 14"], quantity: 1, price: 15000000 },
      {
        product_id: byProduct["Wireless Headset"],
        quantity: 2,
        price: 1200000,
      },
    ],
    status: "completed",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Bob Smith"],
    order_date: ISODate("2024-02-05T08:10:00Z"),
    items: [
      { product_id: byProduct["Coffee Beans 1kg"], quantity: 5, price: 220000 },
      { product_id: byProduct["Running Shoes"], quantity: 1, price: 900000 },
    ],
    status: "completed",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Charlie Brown"],
    order_date: ISODate("2024-03-21T14:00:00Z"),
    items: [
      { product_id: byProduct["Smartphone X"], quantity: 1, price: 7000000 },
    ],
    status: "pending",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Diana Evans"],
    order_date: ISODate("2024-04-02T09:35:00Z"),
    items: [
      { product_id: byProduct["Tablet Air"], quantity: 2, price: 4500000 },
      {
        product_id: byProduct["Mechanical Keyboard"],
        quantity: 1,
        price: 1800000,
      },
    ],
    status: "completed",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Evan Thomas"],
    order_date: ISODate("2024-05-18T12:25:00Z"),
    items: [
      { product_id: byProduct["Running Shoes"], quantity: 3, price: 900000 }, // qty > 2
      {
        product_id: byProduct["Jacket Windbreaker"],
        quantity: 1,
        price: 650000,
      },
    ],
    status: "completed",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Alice Johnson"],
    order_date: ISODate("2024-06-07T16:50:00Z"),
    items: [
      { product_id: byProduct["Coffee Beans 1kg"], quantity: 2, price: 220000 },
    ],
    status: "cancelled",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Farah Rahma"],
    order_date: ISODate("2024-08-11T11:00:00Z"),
    items: [
      {
        product_id: byProduct["Wireless Headset"],
        quantity: 1,
        price: 1200000,
      },
      {
        product_id: byProduct["Mechanical Keyboard"],
        quantity: 1,
        price: 1800000,
      },
    ],
    status: "completed",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Charlie Brown"],
    order_date: ISODate("2024-10-03T18:40:00Z"),
    items: [
      { product_id: byProduct["Tablet Air"], quantity: 3, price: 4500000 }, // qty > 2
      {
        product_id: byProduct["Coffee Beans 1kg"],
        quantity: 10,
        price: 220000,
      }, // qty > 2
    ],
    status: "completed",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Evan Thomas"],
    order_date: ISODate("2024-11-22T07:15:00Z"),
    items: [
      { product_id: byProduct["Smartphone X"], quantity: 2, price: 7000000 },
    ],
    status: "pending",
  },
  {
    _id: ObjectId(),
    customer_id: byCustomer["Bob Smith"],
    order_date: ISODate("2024-12-05T13:05:00Z"),
    items: [
      { product_id: byProduct["Laptop Pro 14"], quantity: 1, price: 15000000 },
      { product_id: byProduct["Running Shoes"], quantity: 2, price: 900000 },
    ],
    status: "completed",
  },
];
db.orders.insertMany(orders);

// 4) OPSIONAL: CEK ISI SINGKAT
// db.customers.find().pretty();
// db.products.find().pretty();
// db.orders.find().pretty();
